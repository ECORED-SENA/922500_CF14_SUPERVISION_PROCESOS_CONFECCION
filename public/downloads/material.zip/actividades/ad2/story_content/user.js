function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6FuZ0fspMPa":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

