function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5W96af3Hkl2":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

