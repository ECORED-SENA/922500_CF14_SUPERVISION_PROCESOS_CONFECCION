function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5VUjn4hFapm":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

